﻿using System;

namespace UnityContainerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Types of DI");
            Driver driver = new Driver(new BMW());
            driver.RunCar();
        }
    }

    public interface ICar
    {
        int Run();
    }

    public class BMW : ICar
    {
        private int _Miles = 0;

        public int Run()
        {
            return ++_Miles;
        }
    }
    public class Ford : ICar
    {
        private int _Miles = 0;

        public int Run()
        {
            return ++_Miles;
        }
    }
    public class Audi : ICar
    {
        private int _Miles = 0;

        public int Run()
        {
            return ++_Miles;
        }
    }

    public class Driver
    {
        private ICar _car = null;
        public Driver(ICar car)
        {
            _car = car;
        }

        public void RunCar()
        {
            Console.WriteLine("Running{0} - {1} Mile", _car.GetType().Name, _car.Run());
        }
    }
}
